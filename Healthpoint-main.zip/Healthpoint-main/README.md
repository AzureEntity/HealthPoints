# healthpoint

## Step 1:
[Install Nodejs](https://nodejs.org/en/download/current)

## Step 2:
install firebase and it's tools
Run these commands on <br />
```npm install firebase``` <br />
```npm -g install firebase tools``` <br />

## Step 3:
clone/download this repo

## Step 4:
Open this folder in vscode and open terminal <br />
run this command <br /> 
```npm i webpack webpack-cli -D```

## Step 5:
Run the website locally

## Step 6:
Learn GitHub commands and start contributing

